/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>

int main()
{
    char ch[]="abcdefghijkl";
    char ch1[]="abcdefghijkl";
    strcpy(ch1,ch);
    strcat(ch,ch1);
    printf("%ld\n",strlen(ch));
    printf("%ld\n",sizeof(ch));
    printf("%s\n",ch1);
    printf("%s\n",ch);
    printf("%d\n",strcmp(ch,ch1));
    return 0;
    
/*length=strlen();
size= sizeof();
concatenate=strcat();
copy=strcpy();
compare=strcmp();*/

}
